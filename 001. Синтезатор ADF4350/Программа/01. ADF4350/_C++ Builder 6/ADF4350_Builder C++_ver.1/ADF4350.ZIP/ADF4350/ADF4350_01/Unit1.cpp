//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------






















void __fastcall TForm1::CheckBox1Click(TObject *Sender)
{
  if(CheckBox1->Checked==true)
  {
    StaticText18->Visible=true;
    ComboBox7->Visible=true;
    ComboBox7->Text=1;
  }
  else
  {
    StaticText18->Visible=false;
    ComboBox7->Visible=false;
    ComboBox7->Text=1;
  }
}
//---------------------------------------------------------------------------

