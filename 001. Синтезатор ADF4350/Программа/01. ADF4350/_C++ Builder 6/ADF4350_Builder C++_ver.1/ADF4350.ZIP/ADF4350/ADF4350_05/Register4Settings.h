//---------------------------------------------------------------------------

#ifndef Register4SettingsH
#define Register4SettingsH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
//---------------------------------------------------------------------------
class TForm7 : public TForm
{
__published:	// IDE-managed Components
  TGroupBox *GroupBox1;
  TStaticText *StaticText1;
  TStaticText *StaticText2;
  TComboBox *ComboBox1;
  TCheckBox *CheckBox1;
  TComboBox *ComboBox2;
  TStaticText *StaticText3;
  TComboBox *ComboBox3;
  TComboBox *ComboBox4;
  TStaticText *StaticText4;
  TStaticText *StaticText5;
  TStaticText *StaticText6;
  TButton *Button1;
  TButton *Button2;
  void __fastcall CheckBox1Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
  __fastcall TForm7(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm7 *Form7;
//---------------------------------------------------------------------------
#endif
