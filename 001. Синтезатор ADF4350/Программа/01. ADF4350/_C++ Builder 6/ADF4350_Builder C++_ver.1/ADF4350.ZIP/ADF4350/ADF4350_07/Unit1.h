//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
  TGroupBox *Reference;
  TGroupBox *OtherOptions;
  TButton *Button7;
  TButton *Button9;
  TButton *Button5;
  TButton *Button10;
  TButton *Button11;
  TGroupBox *GroupBox1;
  TGroupBox *GroupBox2;
  TEdit *Edit2;
  TStaticText *StaticText1;
  TStaticText *StaticText2;
  TComboBox *ComboBox1;
  TStaticText *StaticText3;
  TEdit *Edit1;
  TStaticText *StaticText4;
  TComboBox *ComboBox2;
  TStaticText *StaticText5;
  TStaticText *StaticText6;
  TComboBox *ComboBox3;
  TStaticText *StaticText7;
  TStaticText *StaticText8;
  TComboBox *ComboBox4;
  TStaticText *StaticText9;
  TComboBox *ComboBox5;
  TComboBox *ComboBox6;
  TStaticText *StaticText10;
  TRadioButton *RadioButton3;
  TRadioButton *RadioButton4;
  TCheckBox *CheckBox1;
  TCheckBox *CheckBox2;
  TCheckBox *CheckBox3;
  TCheckBox *CheckBox4;
  TCheckBox *CheckBox5;
  TCheckBox *CheckBox6;
  TGroupBox *GroupBox3;
  TRadioButton *RadioButton1;
  TRadioButton *RadioButton2;
  TEdit *Edit3;
  TEdit *Edit4;
  TStaticText *StaticText11;
  TEdit *Edit5;
  TStaticText *StaticText12;
  TStaticText *StaticText13;
  TStaticText *StaticText14;
  TButton *Button1;
  TButton *Button2;
  TGroupBox *GroupBox4;
  TStaticText *StaticText15;
  TEdit *Edit6;
  TStaticText *StaticText16;
  TRadioButton *RadioButton5;
  TRadioButton *RadioButton6;
  TRadioButton *RadioButton7;
  TGroupBox *GroupBox5;
  TLabel *Label2;
  TLabel *Label3;
  TLabel *Label4;
  TLabel *Label5;
  TLabel *Label6;
  TLabel *Label7;
  TLabel *Label8;
  TLabel *Label9;
  TLabel *Label10;
  TLabel *Label11;
  TButton *Button3;
  TButton *Button4;
  TLabel *Label12;
  TStaticText *StaticText17;
  TLabel *Label13;
  TLabel *Label14;
  TComboBox *ComboBox7;
  TStaticText *StaticText18;
  TLabel *Label1;
  TTimer *Timer1;
  void __fastcall CheckBox1Click(TObject *Sender);
  void __fastcall CheckBox6Click(TObject *Sender);
  void __fastcall Edit2Change(TObject *Sender);
  void __fastcall StaticText17DblClick(TObject *Sender);
  void __fastcall Button9Click(TObject *Sender);
  void __fastcall Button7Click(TObject *Sender);
  void __fastcall Button10Click(TObject *Sender);
  void __fastcall Button5Click(TObject *Sender);
  void __fastcall Button11Click(TObject *Sender);
  void __fastcall RadioButton1Click(TObject *Sender);
  void __fastcall RadioButton2Click(TObject *Sender);
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall Button2Click(TObject *Sender);
  void __fastcall RadioButton6Click(TObject *Sender);
  void __fastcall Timer1Timer(TObject *Sender);
  void __fastcall Edit6Change(TObject *Sender);
  void __fastcall RadioButton7Click(TObject *Sender);
  void __fastcall Edit3Change(TObject *Sender);
  void __fastcall Edit4Change(TObject *Sender);
  void __fastcall ComboBox1Change(TObject *Sender);
  void __fastcall Edit1Change(TObject *Sender);
  void __fastcall ComboBox7Change(TObject *Sender);
  void __fastcall Edit5Change(TObject *Sender);
private:	// User declarations
public:		// User declarations
  int REFin, R, T;    // reference frequency input, reference division factor, reference divide-by-2 bit
  int ChS;            // Channel Spacing
  double Fpfd, D, OD; // PFD frequency, RF REFin doubler bit, Output Devider
  __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
 